/* @preserve
    Copyright (c) 2005-2016, Mendix bv. All rights reserved.
    See mxclientsystem/licenses.txt for third party licenses that apply.
*/
(self.mxJsonp=self.mxJsonp||[]).push([[2],{4337:(e,s,l)=>{l.r(s),l.d(s,{getSQLTablePrefix:()=>t,setSQLTablePrefix:()=>a,toUserScopedTableName:()=>f});let o="";const t=()=>o,a=e=>{o=e},f=e=>o?`${o}$${e}`:e}}]);
